# 
## A virtual currency storage application
   It includes generating mnemonics, creating wallets, importing wallets through mnemonics, private keys and JSON, exporting mnemonics, private keys, JSON strings, transfer, etc    
 ![image](https://raw.githubusercontent.com/DywaneQ/ETHWallet/master/img/Screenshot_2018-05-04-19-28-50-432_com.gongchuang.ethtoken.png)
  
