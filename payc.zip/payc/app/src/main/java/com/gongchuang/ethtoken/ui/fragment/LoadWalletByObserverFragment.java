package com.gongchuang.ethtoken.ui.fragment;

import com.gongchuang.ethtoken.R;
import com.gongchuang.ethtoken.base.BaseFragment;

/**
 * Created by dwq on 2018/3/22/022.
 * e-mail:lomapa@163.com
 */

public class LoadWalletByObserverFragment extends BaseFragment {
    @Override
    public int getLayoutResId() {
        return R.layout.fragment_load_wallet_by_observer;
    }

    @Override
    public void attachView() {

    }

    @Override
    public void initDatas() {

    }

    @Override
    public void configViews() {

    }
}
