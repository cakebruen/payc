package com.gongchuang.ethtoken.event;

/**
 * Created by dwq on 2018/3/27/027.
 * e-mail:lomapa@163.com
 */

public class DeleteWalletSuccessEvent {
}
