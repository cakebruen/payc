package com.gongchuang.ethtoken.api;

/**
 * Created by dwq on 2018/3/13/013.
 * e-mail:lomapa@163.com
 */

public interface TokenApiService {

}
